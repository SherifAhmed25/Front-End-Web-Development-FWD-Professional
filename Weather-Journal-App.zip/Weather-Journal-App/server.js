const express = require('express');

const app = express();

const cors = require("cors");

app.use(cors());

const bodyParser = require("body-parser");

app.use(bodyParser.urlencoded( { extended : false } ) );

app.use(bodyParser.json());

let data = null ;

app.use(express.static("website"));

const port = 4000;





const listen = (req,res) => {
    console.log(`Server is running on port: ${port}`)
}
app.listen(port,listen);

const getData = (req,res) => {
    console.log("server");
    res.send(data);
}

app.get("/GET", getData);

const postData = (req,res) => {
    
     const newData = {
        date : req.body.date,
        temperature : req.body.temperature,
        feeling : req.body.feeling
    }
    data = newData;
    res.send(data);
}

app.post("/POST",postData);



