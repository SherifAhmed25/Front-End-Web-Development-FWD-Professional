/* Global Variables */
// Create a new date instance dynamically with JS

// API Keys after signing up in OpenWeatherMap API

const baseURL = "https://api.openweathermap.org/data/2.5/weather?zip=";
const keyAPI = "&appid=44ab76a4cff6008405e85eace0b5f86c&units=metric";

// Checking InputValidaty if not empty


// function for Fetching weather data from website
const getWeatherData = async (baseURL, key, zip) => {
  try {
    const response = await fetch(baseURL + zip + key);
    const data = await response.json();
    console.log(data);
    return data;
  } catch (err) {
    console.log(err);
  }
};
// function for Posting the data from server 
const postCurrentData = async (url = "/POST", data) => {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    const NewD = await response.json();

    return NewD;
  } catch (err) {
    console.log(err);
  }
};
//  function updates the website by the data in the server server
const UIupdate = async () => {
  try {
    const request = await fetch("/GET");
    const data = await request.json();
    console.log(data);
    // assign the divs in the html to the values
    document.getElementById("date").innerHTML = data.date;
    document.getElementById("temp").innerHTML = data.temperature;
    document.getElementById("content").innerHTML = data.feeling;

    return data;
  } catch (err) {
    console.log(err);
  }
};
// addlistner function 
const generateButton = () => {
  let d = new Date();
  let newDate = d.getMonth() + "." + d.getDate() + "." + d.getFullYear();
  // assigning the values entered 
  const zipCode = document.getElementById("zip").value;
  const feelings = document.getElementById("feelings").value;

 
 // firing the function with their parameters
  getWeatherData(baseURL, keyAPI, zipCode).then((data) =>
    postCurrentData("/POST", {
      date: newDate,
      temperature: data.main.temp,
      feeling: feelings,
    }).then(() => UIupdate())
  );
};

// addlistner function fire generateButton function while clicking on generate
document.getElementById("generate").addEventListener("click", generateButton);
