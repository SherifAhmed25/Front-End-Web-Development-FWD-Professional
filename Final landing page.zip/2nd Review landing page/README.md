# Landing Page Project

## Table of Contents

- [Landing Page Project](#landing-page-project)
  - [Table of Contents](#table-of-contents)
  - [Description](#description)
  - [Author](#author)


## Description
The First landing Page project was successfully done by achieving the navigation bar and Linking its list with the sections in the page and in the first Review the sectionsc made active by scrolling over the page also it is updated by the activity of mobile phones then in the second review the navigation bar anchors was updated to be active as the section as mentioned in the 2nd review
thanks hope to not get the third review :)
//note//
Sorry for the lot of comments 



## Author

Sherif Ahmed El Sayed 

## Technologies Used

1. HTML
2. CSS
3. JavaScript