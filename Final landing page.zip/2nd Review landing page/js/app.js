const sections = document.querySelectorAll("section");
const getmenulink = document.getElementsByClassName("menu__link");
// function to create Navigation bar
const createNav = () => {
  const frag = document.createDocumentFragment(); // make fragment

  for (let i = 0; i < sections.length; i++) {
    // loop over length of sections

    const createli = document.createElement("li");
    const createAnch = document.createElement("a");
    const getdata = sections[i].getAttribute("data-nav");

    

    createAnch.setAttribute("class", "menu__link"); // adding CSS
    // combing the anchors and lists in the fragment
    createAnch.innerHTML = getdata;
    createli.appendChild(createAnch);
    frag.appendChild(createli);
  }
  document.getElementById("navbar__list").appendChild(frag);
};
// calling function
createNav();

const navBarList = document.getElementById("navbar__list");
// function scrolling
const scrolling = (eve) => {
  eve.preventDefault();
  const targ = eve.target;
  const targe = targ.innerHTML;
  const newSecID = targe.toLowerCase().split(" ").join("");
  const sec = document.getElementById(newSecID);
  sec.scrollIntoView({ behavior: "smooth" });
};
// by clicking on navigation bar list fire function scrolling
navBarList.addEventListener("click", scrolling, false);

// default function adjust the dimentions of the section in order to take the activity or not
const isInViewport = (e) => {
  const dimensions = e.getBoundingClientRect();
  return (
    // adjust the dimentions
    dimensions.top >= 0 &&
    dimensions.left >= 0 &&
    dimensions.bottom * 0.7 <=
      (window.innerHeight || document.documentElement.clientHeight) &&
    dimensions.right <=
      (window.innerWidth || document.documentElement.clientWidth)
  );
};

// adjust the activity of the sections
const changecss = () => {
  // loop over the sections
  for (let i = 0 ; i < sections.length;i++){

    if (isInViewport( sections[i])) {
      // get the section and the anchor to take the diffrent CSS
      sections[i].classList.add("your-active-class");
      getmenulink[i].classList.add("anchorCSS");
    }
    //if section in the specific dimensions will remove and take the activity
    else {
      sections[i].classList.remove("your-active-class");
      getmenulink[i].classList.remove("anchorCSS");
  }
  }
};
// by scrolling it will fire the css function
document.addEventListener("scroll", changecss, false);

